#include <ESP8266WiFi.h>
#include <WiFiUdp.h>
#include <F1_25_UDP.h>
#include <Adafruit_NeoPixel.h>

// ====== WiFi settings ======
const char *SSID     = "wifi-ssid"; //Change this to the name of your 2.4 ghz WiFi Network
const char *Password = "wifi-password"; //Change this to the password
const int  localPort = 20777;

// ====== NeoPixel settings ======
#define LED_PIN   5       // If this gives an error change this to D1 or another port on the ESP8266
#define LED_COUNT 14       // Change this to the amount of leds on your strip

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

F1_25_Parser* parser;

// State-tracking
uint8_t lastWeather         = 255;
uint8_t lastSafetyCarStatus = 255;

// Blink-state (so the led strip can blink yellow or red)
bool blinkState = false;
unsigned long lastBlinkMillis = 0;
const unsigned long BLINK_INTERVAL = 500; // ms

// Red flag state (red blinking)
bool redFlagActive = false;
unsigned long redFlagStartMillis = 0;
const unsigned long RED_FLAG_DURATION_MS = 10000; // 10 seconds

void startWiFi();

// ====== Helper: Strip one full colour ======
void setStripColor(uint8_t r, uint8_t g, uint8_t b)
{
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
  }
  strip.show();
}

// ====== weather ======
void updateWeatherLeds(uint8_t weather)
{
  // Weather codes:
  // 0 = clear, 1 = light cloud, 2 = overcast,
  // 3 = light rain, 4 = heavy rain, 5 = storm

  // you can change the RGB codes 
  switch (weather) {
    case 0: // clear -> light yellow
      setStripColor(255, 255, 100);   // light yellow
      Serial.println("Weather: Clear (light yellow)");
      break;

    case 1: // light cloud -> light blue
      setStripColor(120, 190, 255);   // light blue
      Serial.println("Weather: Light cloud (light blue)");
      break;

    case 2: // overcast -> white
      setStripColor(255, 255, 255);   // white
      Serial.println("Weather: Overcast (white)");
      break;

    case 3: // light rain -> light purple
      setStripColor(210, 140, 255);   // light puprle
      Serial.println("Weather: Light rain (light purple)");
      break;

    case 4: // heavy rain -> purple
      setStripColor(170, 90, 230);    // purple
      Serial.println("Weather: Heavy rain (medium purple)");
      break;

    case 5: // storm -> dark purple
      setStripColor(110, 0, 180);     // dark purple
      Serial.println("Weather: Storm (dark purple)");
      break;

    default:
      setStripColor(0, 0, 0);         // Unknown: off
      Serial.print("Weather: Unknown code ");
      Serial.println(weather);
      break;
  }
}

// ====== General blink-helper (colour on/off) ======
void updateBlink(uint8_t r, uint8_t g, uint8_t b)
{
  unsigned long now = millis();
  if (now - lastBlinkMillis >= BLINK_INTERVAL) {
    lastBlinkMillis = now;
    blinkState = !blinkState;

    if (blinkState) {
      setStripColor(r, g, b);  // colour on
    } else {
      setStripColor(0, 0, 0);  // off
    }
  }
}

void setup()
{
  parser = new F1_25_Parser();

  Serial.begin(115200);
  delay(100);

  startWiFi();
  parser->begin(localPort);

  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  strip.begin();
  strip.show(); // all leds off
}

void loop()
{
  parser->read();

  PacketSessionData* session = parser->packetSessionData();
  PacketEventData*   event   = parser->packetEventData();

  // ---- detects red flag via event packet ("RDFL") ----
  if (event != nullptr) {
    uint8_t e0 = event->m_eventStringCode(0);
    uint8_t e1 = event->m_eventStringCode(1);
    uint8_t e2 = event->m_eventStringCode(2);
    uint8_t e3 = event->m_eventStringCode(3);

    if (e0 == 'R' && e1 == 'D' && e2 == 'F' && e3 == 'L') {
      // Red flag event
      redFlagActive      = true;
      redFlagStartMillis = millis();
      blinkState         = false;         // reset blink
      lastBlinkMillis    = millis();
      Serial.println("Red flag event detected (RDFL)");
    }
  }

  if (session != nullptr) {
    uint8_t weather         = session->m_weather();
    uint8_t safetyCarStatus = session->m_safetyCarStatus();
    // safetyCarStatus:
    // 0 = no safety car
    // 1 = full safety car
    // 2 = virtual safety car
    // 3 = formation lap safety car

    // Debug + state reset when status-change
    if (safetyCarStatus != lastSafetyCarStatus) {
      Serial.print("Safety car status changed to: ");
      Serial.println(safetyCarStatus);
      lastSafetyCarStatus = safetyCarStatus;

      // reset blink if new safety car status
      blinkState = false;
      lastBlinkMillis = millis();
    }

    unsigned long now = millis();

    // ---- priority 1: red flag (red blinking ----
    if (redFlagActive && (now - redFlagStartMillis) < RED_FLAG_DURATION_MS) {
      // Rood knipperende strip
      updateBlink(255, 0, 0);
    } else {
      // red flag over / timer stops
      redFlagActive = false;

      // ---- priority 2: safety car (full, virtual, formation) → yellow blinking ----
      if (safetyCarStatus == 1 || safetyCarStatus == 2 || safetyCarStatus == 3) {
        // Full / virtual / formation lap safety car
        updateBlink(255, 255, 0); // yellow blinking
      } else {
        // ---- Show weather when there is no safety car ----
        if (weather != lastWeather) {
          updateWeatherLeds(weather);
          lastWeather = weather;

          int8_t trackTemp = session->m_trackTemperature();
          int8_t airTemp   = session->m_airTemperature();
          Serial.print("Track temp: ");
          Serial.print(trackTemp);
          Serial.print("C | Air temp: ");
          Serial.print(airTemp);
          Serial.println("C");
        }
      }
    }

    digitalWrite(LED_BUILTIN, LOW);
  } else {
    // has not received server packet
    digitalWrite(LED_BUILTIN, HIGH);
  }

  delay(50);
}

// ====== WiFi unchanged ======
void startWiFi()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, Password);

  Serial.print("Attempting to connect to ");
  Serial.println(SSID);

  uint8_t i = 0;
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print('.');
    delay(250);

    if ((++i % 16) == 0)
    {
      Serial.println(F(" still trying to connect"));
    }
  }

  Serial.print(F("Connection Successful | IP Address: "));
  Serial.println(WiFi.localIP());
}