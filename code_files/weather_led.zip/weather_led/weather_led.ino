#include <ESP8266WiFi.h>
#include <WiFiUdp.h>
#include <F1_25_UDP.h>
#include <Adafruit_NeoPixel.h>

// ====== WiFi settings ======
const char *SSID     = "Ziggo1624679"; //Change this to the name of your 2.4 ghz WiFi Network
const char *Password = "Sky6kmmbm8aw";  //Change this to the password
const int  localPort = 20777; // this is the UDP port that you have to change in the F1 25 menu

// ====== NeoPixel settings ======
#define LED_PIN   5       // If this gives an error change this to D1 or another port on the ESP8266
#define LED_COUNT 14       // Change this to the amount of leds on your strip

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

F1_25_Parser* parser;
uint8_t lastWeather = 255; 

void startWiFi();

void setup()
{
  parser = new F1_25_Parser();

  Serial.begin(115200);
  delay(100);

  startWiFi();

  parser->begin(localPort);

// The onbord led will turn on
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  strip.begin();
  strip.show(); 
}

void setStripColor(uint8_t r, uint8_t g, uint8_t b)
{
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
  }
  strip.show();
}

void updateWeatherLeds(uint8_t weather)
{
  // Weather codes:
  // 0 = clear, 1 = light cloud, 2 = overcast,
  // 3 = light rain, 4 = heavy rain, 5 = storm

  switch (weather) {
    case 0:
      setStripColor(255, 255, 150);
      Serial.println("Weather: Clear (light yellow)");
      break;

    case 1:
      setStripColor(120, 190, 255);
      Serial.println("Weather: Light cloud (light blue)");
      break;

    case 2:
      setStripColor(255, 255, 255);
      Serial.println("Weather: Overcast (white)");
      break;

    case 3: 
      setStripColor(210, 140, 255);  
      Serial.println("Weather: Light rain (light purple)");
      break;

    case 4: 
      setStripColor(170, 90, 230);    
      Serial.println("Weather: Heavy rain (medium purple)");
      break;

    case 5: 
      setStripColor(110, 0, 180); 
      Serial.println("Weather: Storm (dark purple)");
      break;

    default:
      setStripColor(0, 0, 0); 
      Serial.print("Weather: Unknown code ");
      Serial.println(weather);
      break;
  }
}

void loop()
{
  parser->read();

  PacketSessionData* session = parser->packetSessionData();

  if (session != nullptr) {
    uint8_t weather = session->m_weather(); 

    if (weather != lastWeather) {
      updateWeatherLeds(weather);
      lastWeather = weather;

      int8_t trackTemp = session->m_trackTemperature();
      int8_t airTemp   = session->m_airTemperature();
      Serial.print("Track temp: ");
      Serial.print(trackTemp);
      Serial.print("C | Air temp: ");
      Serial.print(airTemp);
      Serial.println("C");
    }

    digitalWrite(LED_BUILTIN, LOW);
  } else {

    digitalWrite(LED_BUILTIN, HIGH);
  }

  delay(250); 
}

void startWiFi()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, Password);

  Serial.print("Attempting to connect to ");
  Serial.println(SSID);

  uint8_t i = 0;
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print('.');
    delay(250);

    if ((++i % 16) == 0)
    {
      Serial.println(F(" still trying to connect"));
    }
  }

  Serial.print(F("Connection Successful | IP Address: "));
  Serial.println(WiFi.localIP());
}