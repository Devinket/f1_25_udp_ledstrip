#include <ESP8266WiFi.h>
#include <WiFiUdp.h>
#include <F1_25_UDP.h>
#include <Adafruit_NeoPixel.h>

const char *SSID     = "wifi-ssid"; //Change this to the name of your 2.4 ghz WiFi Network
const char *Password = "wifi-password"; //Change this to the password
const int localPort  = 20777; // this is the UDP port that you have to change in the F1 25 menu

#define LED_PIN   5 // If this gives an error change this to D1 or another port on the ESP8266
#define NUM_LEDS  14 // Change this to the amount of leds on your strip

Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

void startWiFi();

F1_25_Parser* parser;

void setup()
{
  parser = new F1_25_Parser();
  Serial.begin(115200);
  startWiFi();
  parser->begin(localPort);

  strip.begin();
  strip.setBrightness(80);
  strip.fill(strip.Color(0, 0, 0)); // Off by default
  strip.show();
}

void loop()
{
  parser->read();

  unsigned int playerCar = parser->packetCarTelemetryData()->m_playerCarIndex();
  uint8_t drs = parser->packetCarTelemetryData()->m_carTelemetryData(playerCar).m_drs;

  if (drs) {
    strip.fill(strip.Color(0, 255, 0)); // DRS on → green
    strip.show();
    Serial.println("DRS Enabled");
  } else {
    strip.fill(strip.Color(0, 0, 0));   // DRS off → off
    strip.show();
  }

  delay(250);
}

void startWiFi()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, Password);
  Serial.print("Attempting to connect to ");
  Serial.println(SSID);

  uint8_t i = 0;
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print('.');
    delay(250);

    if ((++i % 16) == 0)
    {
      Serial.println(F(" still trying to connect"));
    }
  }

  Serial.print(F("Connection Successful | IP Address: "));
  Serial.println(WiFi.localIP());
}
